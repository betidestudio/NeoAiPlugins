# NeoAI Plugin v0.2 - Test Release

This is a test release for auto-update functionality.

## Changes in v0.2:
- Added plugin versioning system
- Implemented auto-update functionality 
- Fixed various bugs

## Installation:
Extract this zip to your plugin directory and restart Unreal Engine.

**Note:** This is a test release for auto-update functionality testing.